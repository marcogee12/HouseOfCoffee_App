﻿using System;
using Enumerations;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structures
{
    public struct CoffeeHouseCalculations
    {
        private bool overTime;
        public decimal PayRate;
        public CoffeeSize CoffeeSize;
        public Sandwich Sandwich;
        public decimal CoffeePrice;
        public decimal SandwichPrice;
        public decimal SaleSmCoffeePrice;
        public decimal SaleMedCoffeePrice;
        public decimal SaleLarCoffePrice;
        public decimal SaleEggSandwichPrice;
        public decimal SaleChickenSandwichPrice;
        public decimal SMCupPrice;
        public decimal MedCupPrice;
        public decimal LarCupPrice;
        public decimal EggSandPrice;
        public decimal ChickBisPrice;
        public decimal TotalSales;
        public decimal EmployeePayroll;
        public decimal TotalPayRoll;
        public bool OverTime()
        {
            return this.overTime;
        }
        public void SetOverTime(bool overTime)
        {
            this.overTime = overTime;
        }
    }
}

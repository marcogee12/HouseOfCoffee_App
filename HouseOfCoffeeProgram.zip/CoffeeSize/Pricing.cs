﻿using System;
using Enumerations;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesPrice
{
    public class Pricing
    {
        public Enumerations.CoffeeSize CoffeeSize { get; set; }
        public Sandwich Sandwich { get; set; }
        public double SaleSmCoffeePrice { get; set; }
        public double SaleMedCoffeePrice { get; set; }
        public double SaleLarCoffeePrice { get; set; }
        public double SMCupPrice { get; set; }
        public double MedCupPrice { get; set; }
        public double LarCupPrice { get; set; }
        public double EggSandPrice { get; set; }
        public double ChickBisPrice { get; set; }
        public double CoffeePrice { get; set; }
        public double EggPrice { get; set; }
        public double ChickPrice { get; set; }

    }
}

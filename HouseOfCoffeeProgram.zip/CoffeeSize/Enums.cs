﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enumerations
{
    public enum CoffeeSize: short
    {
        small,
        medium,
        large
    }

    public enum  Sandwich: short
    {
        eggSandwich,
        chickenBiscuit
    }
}

﻿using System;
using Enumerations;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Payroll
{
    public class BasePayroll
    {
        private bool overTime;

        public BasePayroll()
        {
            overTime = false;
        }

        public double PayRate {get; set;}

        public virtual bool OverTime()
        {
            return this.overTime;
        }

        public virtual void SetOverTime(bool overTime)
        {
            this.overTime = overTime;
        }
    }
}

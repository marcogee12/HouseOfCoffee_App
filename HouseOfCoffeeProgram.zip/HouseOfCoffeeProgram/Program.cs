using System;
using SmCoffee;
using MedCoffee;
using LarCoffee;
using EggSand;
using ChickBis;
using SalesPrice;
using Enumerations;
using EmployeePay;
using Payroll;
using Structures;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HouseOfCoffeeProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            MainMenu();
        }

        public static void MainMenu()
        {
            SmallCoffee smallCoffee = new SmallCoffee
            {
                CoffeeSize = Enumerations.CoffeeSize.small,
                SaleSmCoffeePrice = 1.00,
                SMCupPrice = 0.1,
            };
            MediumCoffee mediumCoffee = new MediumCoffee
            {
                CoffeeSize = Enumerations.CoffeeSize.medium,
                SaleMedCoffeePrice = 3.00,
                MedCupPrice = 0.15,
            };
            LargeCoffee largeCoffee = new LargeCoffee
            {
                CoffeeSize = Enumerations.CoffeeSize.large,
                SaleLarCoffeePrice = 5.00,
                LarCupPrice = 0.2,
            };
            try
            {
                Console.WriteLine("Enter total number of sales for a Small Coffee");
                double s = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter total number of sales for a Medium Coffee");
                double m = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter total number of sales for a Large Coffee");
                double l = Convert.ToDouble(Console.ReadLine());
                double TotalSmall = (s * smallCoffee.SaleLarCoffeePrice) + (s * smallCoffee.SMCupPrice);
                double TotalMed = (m * mediumCoffee.SaleMedCoffeePrice) + (s * mediumCoffee.MedCupPrice);
                double TotalLar = (l * largeCoffee.SaleLarCoffeePrice) + (l * largeCoffee.LarCupPrice);
                double TotalCoffeeSales = TotalSmall + TotalMed + TotalLar;
                Console.WriteLine($"Your total coffee sales is ${TotalCoffeeSales}.");

                EggSandwich eggsandwich = new EggSandwich
                {
                    Sandwich = Enumerations.Sandwich.eggSandwich,
                    EggSandPrice = 5.5,
                    EggPrice = 0.95,
                };
                ChickenBiscuit chickenBiscuit = new ChickenBiscuit
                {
                    Sandwich = Enumerations.Sandwich.chickenBiscuit,
                    ChickBisPrice = 7.5,
                    ChickPrice = 1.2,
                };
                Console.WriteLine("Enter total number of sales for an EggSandwich");
                double e = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter total number of sales for a Chicken Biscuit");
                double c = Convert.ToDouble(Console.ReadLine());
                double TotalEgg = (e * eggsandwich.EggSandPrice) + (e * eggsandwich.EggPrice);
                double TotalChick = (c * chickenBiscuit.ChickBisPrice) + (c * chickenBiscuit.ChickPrice);
                double TotalSandwiches = TotalEgg + TotalChick;
                Console.WriteLine($"Your total sandwich sales is ${TotalSandwiches}.");
                double TotalSales = TotalCoffeeSales + TotalSandwiches;
                Console.WriteLine($"Your total sales is ${TotalSales}.");

                Console.WriteLine("Enter the number of hours Employee one worked");
                double E1 = Convert.ToDouble(Console.ReadLine());
                double OT1 = 0;
                if (E1 > 40)
                {
                    OT1 = E1 - 40;
                    E1 = 40;
                }
                else
                {
                }
                double RegPay1 = 12.5 * E1;
                double OTP1 = OT1 * (12.5 * 1.5);
                double T1 = RegPay1 + OTP1;
                EmployeePayroll one = new EmployeePayroll
                {
                    PayRate = E1,
                };
                Console.WriteLine($"Employees Payroll before OverTime is ${RegPay1}.");
                Console.WriteLine($"Employees OverTime Pay is ${OTP1}.");
                Console.WriteLine($"Employees Total Payroll is ${T1}.");
                Console.WriteLine("Enter the number of hours Employee two worked");
                double E2 = Convert.ToDouble(Console.ReadLine());
                double OT2 = 0;
                if (E2 > 40)
                {
                    OT2 = E2 - 40;
                    E2 = 40;
                }
                else
                {
                }
                double RegPay2 = 12.5 * E2;
                double OTP2 = OT2 * (12.5 * 1.5);
                double T2 = RegPay2 + OTP2;
                EmployeePayroll two = new EmployeePayroll
                {
                    PayRate = E2,
                };
                Console.WriteLine($"Employees Payroll before OverTime is ${RegPay2}.");
                Console.WriteLine($"Employees OverTime Pay is ${OTP2}.");
                Console.WriteLine($"Employees Payroll is ${T2}.");
                Console.WriteLine("Enter the number of hours Employee three worked");
                double E3 = Convert.ToDouble(Console.ReadLine());
                double OT3 = 0;
                if (E3 > 40)
                {
                    OT3 = E3 - 40;
                    E3 = 40;
                }
                else
                {
                }
                double RegPay3 = 12.5 * E3;
                double OTP3 = OT3 * (12.5 * 1.5);
                double T3 = RegPay3 + OTP3;
                EmployeePayroll three = new EmployeePayroll
                {
                    PayRate = E3,
                };
                Console.WriteLine($"Employees Payroll before OverTime is ${RegPay3}.");
                Console.WriteLine($"Employees OverTime Pay is ${OTP3}.");
                Console.WriteLine($"Employees Payroll is ${T3}.");
                Console.WriteLine("Enter the number of hours Employee four worked");
                double E4 = Convert.ToDouble(Console.ReadLine());
                double OT4 = 0;
                if (E4 > 40)
                {
                    OT4 = E4 - 40;
                    E4 = 40;
                }
                else
                {
                }
                double RegPay4 = 12.5 * E4;
                double OTP4 = OT4 * (12.5 * 1.5);
                double T4 = RegPay4 + OTP4;
                EmployeePayroll four = new EmployeePayroll
                {
                    PayRate = E4,
                };
                Console.WriteLine($"Employees Payroll before OverTime is ${RegPay4}.");
                Console.WriteLine($"Employees OverTime Pay is ${OTP4}.");
                Console.WriteLine($"Employees Payroll is ${T4}.");
                Console.WriteLine("Enter the number of hours Employee five worked");
                double E5 = Convert.ToDouble(Console.ReadLine());
                double OT5 = 0;
                if (E5 > 40)
                {
                    OT5 = E5 - 40;
                    E5 = 40;
                }
                else
                {
                }
                double RegPay5 = 12.5 * E5;
                double OTP5 = OT5 * (12.5 * 1.5);
                double T5 = RegPay5 + OTP5;
                EmployeePayroll five = new EmployeePayroll
                {
                    PayRate = E5,
                };
                Console.WriteLine($"Employees Payroll before OverTime is ${RegPay5}.");
                Console.WriteLine($"Employees OverTime Pay is ${OTP5}.");
                Console.WriteLine($"Employees Payroll is ${T5}.");
                double TotalPayRoll = T1 + T2 + T3 + T4 + T5;
                double TotalOTPay = OTP1 + OTP2 + OTP3 + OTP4 + OTP5;
                double TotalPayBeforeOT = RegPay1 + RegPay2 + RegPay3 + RegPay4 + RegPay5;
                Console.WriteLine($"Total Employee Payroll before OverTime is ${TotalPayBeforeOT}.");
                Console.WriteLine($"Total Employee OverTime Pay is ${TotalOTPay}.");
                Console.WriteLine($"Total Employee Payroll is ${TotalPayRoll}.");
            }
            catch(FormatException)
            {
                Console.Clear();
                Console.WriteLine("You entered an incorrect format! Please try again.");
                MainMenu();
            }
            Console.ReadKey();
        }
    }
}
